#Imports
import os
import glob
import numpy as np
import copy
from qml import Compound
from qml.fchl import generate_representation
from qml.fchl import get_local_symmetric_kernels
from qml.fchl import get_local_kernels
from qml.math import cho_solve

def rep_mol(path, X):
	#Function to generate FCHL representations for molecules
	myfiles = glob.glob(os.path.join(path, '*.xyz'))
	myfiles.sort()
	compounds = []
	for k in myfiles:
	    compounds.append(Compound(xyz=k))
	for c in compounds:
	    coordinates = c.coordinates
	    nuclear_charges = c.nuclear_charges
	    X.append(generate_representation(coordinates,nuclear_charges,max_size=155,cut_distance=9.0,neighbors=429))
	return X

def rep_sol(path, X):
	#Function to generate FCHL representations for solids
	myfiles = glob.glob(os.path.join(path, '*.xyz'))
	myfiles.sort()
	for k in myfiles:
		myfile = open(k,"r")
		mylist = myfile.read().splitlines()
		myfile.close()
		unit_cell = np.array([i.split() for i in mylist[1:4]])
		for i in list(range(len(unit_cell))):
			unit_cell[i] = [float(j) for j in unit_cell[i]]
		unit_cell = np.array(unit_cell, dtype=np.float64)
		unit_cell = np.transpose(unit_cell)
		mycoord = np.array([i.split() for i in mylist[4:]])
		nuclear_charges = []
		choices = {'H': 1, 'C': 6, 'N': 7, 'O': 8, 'F': 9, 'Cl': 17, 'Br': 35, 'I': 53}
		for i in list(range(int(mylist[0]))):
			nuclear_charges.append([choices.get(j) for j in mycoord[i][0]])
		nuclear_charges = np.array(nuclear_charges)
		coordinates = []
		for i in list(range(int(mylist[0]))):
			coordinates.append([float(j) for j in mycoord[i][1:4]])
		coordinates = np.array(coordinates)
		fractional_coordinates = coordinates
		del coordinates
		representation = generate_representation(fractional_coordinates, nuclear_charges, cell=unit_cell, max_size=155, neighbors=429, cut_distance=9.0)
		X.append(representation)
	return X

def e_train(path, Y):
	#Function to read the training energies
	myfiles = glob.glob(os.path.join(path, '*.txt'))
	myfiles.sort()
	for k in myfiles:
		myfile = open(k,"r")
		mylist = myfile.read()
		myfile.close()
		energies = mylist.split()
		Y.append(energies[method])
	return Y

#Select the method
#0: Direct ML
#1: BLYP-NCI
#2: PBE-NCI
#3: TPSS-NCI
#4: SCAN-NCI
#5: B3LYP-NCI
#6: PBE0-NCI
method = 4

#Generate representations for the training set
X_training = []
X_training = rep_mol("training/s66x8", X_training)
X_training = rep_mol("training/bt80", X_training)
X_training = rep_mol("training/x40x10", X_training)
X_training = rep_mol("training/water", X_training)
X_training = np.array(X_training)
np.save("X_training.npy", X_training)

#Generate representations for the test set
X_test = []
X_test = rep_mol("test/s12l", X_test)
X_test = rep_sol("test/x23", X_test)
X_test = np.array(X_test)
np.save("X_test.npy", X_test)

#Construct the kernel matrix for training with a list of sigmas
sigmas = [2.0**8]
K = get_local_symmetric_kernels(X_training, sigmas, cut_distance=9.0, two_body_power=4.0, three_body_power=2.0, two_body_scaling=2.82842712475, three_body_scaling=1.6)
fn_K = "K.npy"
np.save(fn_K, K)

#Construct the kernel matrix for testing with a list of sigmas
L = get_local_kernels(X_test, X_training, sigmas, cut_distance=9.0, two_body_power=4.0, three_body_power=2.0, two_body_scaling=2.82842712475, three_body_scaling=1.6)
fn_L = "L.npy"
np.save(fn_L, L)

#Read the training energies
Y_training = []
Y_training = e_train("training/s66x8", Y_training)
Y_training = e_train("training/bt80", Y_training)
Y_training = e_train("training/x40x10", Y_training)
Y_training = e_train("training/water", Y_training)
Y_training = np.array(Y_training)
np.save("Y_training.npy", X_test)

#Train the model and calculate the predicted energies
lmda = 1e-8
for i in list(range(len(sigmas))):
	K[i][np.diag_indices_from(K[i])] += lmda
	C = copy.deepcopy(K[i])
	alpha = cho_solve(C, Y_training)
	Y_predicted = np.dot(L[i], alpha)
	print(Y_predicted)
